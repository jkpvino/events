SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

DROP TABLE IF EXISTS T_APP_USERS,T_USER_ADDRESS, T_CLASSIFIED, T_CLASSIFIED_IMAGES;

CREATE TABLE IF NOT EXISTS `T_APP_USERS` (
  `id` int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `username` varchar(256) NOT NULL,
  `ProfileImage` text NOT NULL,
  `FullName` varchar(256) NOT NULL,
  `Phone_no` int(10) NOT NULL,
  `OTP` int(10) NOT NULL,
  `Hash_code` int(10) NOT NULL,
  `Online_status` tinyint(4) NOT NULL COMMENT '0 => Offline 1 => Online' ,
  `user_status` tinyint(4) NOT NULL COMMENT '0 => Disable 1 => Enable' ,
  `created_by` varchar(256) NOT NULL,
  `modified_by` varchar(256) NOT NULL,
  `d_created` datetime NOT NULL,
  `d_modified` datetime NOT NULL,
  `is_blocked` tinyint(4) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ;

CREATE TABLE IF NOT EXISTS `T_USER_ADDRESS` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contact_no` int(10) NOT NULL,
  `mobile_no` int(10) NOT NULL,
  `address` varchar(256) NOT NULL,
  `state` varchar(100) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `name_type` tinyint(4) NOT NULL,
  `contact_type` tinyint(4) NOT NULL,
  `mobile_type` tinyint(4) NOT NULL,
  `add_type` tinyint(4) NOT NULL,
  `state_type` tinyint(4) NOT NULL,
  `nationality_type` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT T_USER_ADDRESS_ibfk_1 
  FOREIGN KEY (user_id) REFERENCES T_APP_USERS(id)
  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS T_CLASSIFIED, T_CLASSIFIED_IMAGES;

CREATE TABLE IF NOT EXISTS `T_CLASSIFIED` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  `min_price` DECIMAL(10,0) NOT NULL,
  `max_price` DECIMAL(10,0) NOT NULL,
  `country` varchar(256) DEFAULT NULL,
  `state` varchar(256) DEFAULT NULL,
  `city` varchar(256) DEFAULT NULL,
  `locality` varchar(100) DEFAULT NULL,
  `sub_locality` varchar(100) DEFAULT NULL,
  `user_id` int(11) NULL,
  `admin_id` int(11) NULL,
  `title` varchar(256) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `count_view` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `post_status` int(11) NOT NULL COMMENT '0 => Pending 1 => Approved 2 => Rejected' ,
  `created_by` varchar(100) NOT NULL,
  `approved_by` varchar(100) NOT NULL,
  `d_created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `d_modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `T_CLASSIFIED_IMAGES` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classified_id` int(11) NOT NULL,
  `image` TEXT DEFAULT NULL,
  `sort_order` int(11) NOT NULL,
  `is_default` tinyint(4) NOT NULL COMMENT '1 => Default',
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT T_CLASSIFIED_IMAGES_ibfk_1 
  FOREIGN KEY (classified_id) REFERENCES T_CLASSIFIED(id)
  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `T_PROFESSION` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profession_name` varchar(256) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `display_order` int(10) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0 => Disable 1 => Enable',
  `created_by` varchar(256) NOT NULL,
  `modified_by` varchar(256) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `is_approve` tinyint(4) NOT NULL,
  `approved_by` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ;



DROP TABLE IF EXISTS T_ENQUIRY;
CREATE TABLE IF NOT EXISTS `T_ENQUIRY` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classified_id` int(11) NOT NULL,
  `customer_name` varchar(256) NOT NULL,
  `phone_no` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `template_id` varchar(256) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT T_ENQUIRY_ibfk_1 
  FOREIGN KEY (classified_id) REFERENCES T_CLASSIFIED(id)
  ON DELETE CASCADE
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;