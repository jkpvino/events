<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function getLoggedUserId(){
	// Load Session
	$CI =& get_instance();
    $CI->load->library('session');
	if($CI->session->userdata('isUserLogged')){
		$session_data = $CI->session->userdata('isUserLogged');
		$logid = $session_data['logid'];
	}else{
		$logid = '';
	}
	return $logid;
}



function getLoggedUserInfo(){
	// Load Session
	$CI =& get_instance();
    $CI->load->library('session');
	if($CI->session->userdata('isUserLogged')){
		$session_data = $CI->session->userdata('isUserLogged');
		$logid = $session_data['logid'];
		$userinfo = $CI->user_model->getuserinfobyId($logid);
		$userinfo = $userinfo[0];
	}else{
		$userinfo = '';
	}
	return $userinfo;
}

function isUserLogged(){
	// Load Session
	$CI =& get_instance();
    $CI->load->library('session');
	if($CI->session->userdata('isUserLogged')){
		return true;
	}else{
		return false;
	}
}

function debug($data){
	echo "<pre>"; print_r($data); echo "</pre>"; 
}

function getExtensionInfo($referenceId){
	$CI =& get_instance();
    $CI->load->library('session');
	return $extensionInfo = $CI->user_model->getExtensionInfoByReferenceId($referenceId);

}

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function smtpmailer($to, $from, $from_name = 'Example.com', $subject, $body, $is_gmail = true){error_reporting(E_ALL);
	  require_once(FCPATH.'assests/PHPMailer_v5.1/class.phpmailer.php'); //library added in download source.
        global $error;
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPAuth = true; 
        if($is_gmail)
        {
            $mail->SMTPSecure = 'ssl'; 
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 465;  
            $mail->Username = 'jkprovab@gmail.com';  
            $mail->Password = 'provab@2098@1992';   
        }
        else
        {
            $mail->Host = 'smtp.mail.google.com';
            $mail->Username = 'admin@example.com';  
            $mail->Password = '******';
        }
        $mail->IsHTML(true);
        $mail->From="infobluefills@gmail.com";
        $mail->FromName="bluefills.com";
        $mail->Sender=$from; // indicates ReturnPath header
        $mail->AddReplyTo($from, $from_name); // indicates ReplyTo headers
       // $mail->AddCC('cc@site.com.com', 'CC: to site.com');
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AddAddress($to);
        if(!$mail->Send())
        {
            $error = 'Mail error: '.$mail->ErrorInfo;
            return true;
        }
        else
        {
            $error = 'Message sent!';
            return false;
        }
    }