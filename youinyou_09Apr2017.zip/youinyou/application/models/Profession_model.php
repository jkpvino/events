<?php 
class Profession_model extends CI_Model {

	public function __construct(){
        parent::__construct();
    }

    public function getprofessionlist(){

        $aColumns = array(
            'id',
            'profession_name',
            'status',
            'created',
            'created_by'
        );
        $sIndexColumn = "id";

        /* Total data set length */
        $sQuery = "SELECT COUNT('".$sIndexColumn."') AS row_count FROM T_PROFESSION";
        $rResultTotal = $this->db->query($sQuery);
        $aResultTotal = $rResultTotal->row();
        $iTotal = $aResultTotal->row_count;

        /*
         * Paging
         */
        $sLimit = "";
        $iDisplayStart = $this->input->get_post('start', true);
        $iDisplayLength = $this->input->get_post('length', true);
        if (isset($iDisplayStart) && $iDisplayLength != '-1') {
            $sLimit = "LIMIT " . intval($iDisplayStart) . ", " .
            intval($iDisplayLength);
        }

        $uri_string = $_SERVER['QUERY_STRING'];
        $uri_string = preg_replace("/\%5B/", '[', $uri_string);
        $uri_string = preg_replace("/\%5D/", ']', $uri_string);

        $get_param_array = explode("&", $uri_string);
        $arr = array();
        foreach ($get_param_array as $value) {
            $v = $value;
            $explode = explode("=", $v);
            $arr[$explode[0]] = $explode[1];
        }

        $index_of_columns = strpos($uri_string, "columns", 1);
        $index_of_start = strpos($uri_string, "start");
        $uri_columns = substr($uri_string, 7, ($index_of_start - $index_of_columns - 1));
        $columns_array = explode("&", $uri_columns);
        $arr_columns = array();
        foreach ($columns_array as $value) {
            $v = $value;
            $explode = explode("=", $v);
            if (count($explode) == 2) {
                $arr_columns[$explode[0]] = $explode[1];
            } else {
                $arr_columns[$explode[0]] = '';
            }
        }
        /*
         * Ordering
         */
        $sOrder = "ORDER BY ";
        $sOrderIndex = $arr['order[0][column]'];
        $sOrderDir = $arr['order[0][dir]'];
        $bSortable_ = $arr_columns['columns[' . $sOrderIndex . '][orderable]'];
        if ($bSortable_ == "true") {
            $sOrder .= $aColumns[$sOrderIndex] .
                    ($sOrderDir === 'asc' ? ' asc' : ' desc');
        }

        /*
         * Filtering
         */
        $sWhere = "";
        $sSearchVal = $arr['search[value]'];
        if (isset($sSearchVal) && $sSearchVal != '') {
            $sWhere = "WHERE (";
            for ($i = 0; $i < count($aColumns); $i++) {
                $sWhere .= $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($sSearchVal) . "%' OR ";
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= ')';
        }

        /* Individual column filtering */
        $sSearchReg = $arr['search[regex]'];
        for ($i = 0; $i < count($aColumns); $i++) {
            $bSearchable_ = $arr['columns[' . $i . '][searchable]'];
            if (isset($bSearchable_) && $bSearchable_ == "true" && $sSearchReg != 'false') {
                $search_val = $arr['columns[' . $i . '][search][value]'];
                if ($sWhere == "") {
                    $sWhere = "WHERE ";
                } else {
                    $sWhere .= " AND ";
                }
                $sWhere .= $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($search_val) . "%' ";
            }
        }

        /*
         * SQL queries
         * Get data to display
         */
        $sQuery = "SELECT SQL_CALC_FOUND_ROWS " . str_replace(" , ", " ", implode(", ", $aColumns)) . "
        FROM T_PROFESSION
        $sWhere
        $sOrder
        $sLimit
        ";
        $rResult = $this->db->query($sQuery);

        /* Data set length after filtering */
        $sQuery = "SELECT FOUND_ROWS() AS length_count";
        $rResultFilterTotal = $this->db->query($sQuery);
        $aResultFilterTotal = $rResultFilterTotal->row();
        $iFilteredTotal = $aResultFilterTotal->length_count;

        /*
         * Output
         */
        $sEcho = $this->input->get_post('draw', true);
        $output = array(
            "draw" => intval($sEcho),
            "recordsTotal" => $iTotal,
            "recordsFiltered" => $iFilteredTotal,
            "data" => array()
        );
        foreach ($rResult->result_array() as $aRow) {
            $row = array();
            foreach ($aColumns as $col) {
                $row[] = $aRow[$col];                
            }

            if($row[2] == 1)
                $row[2] = '<span class="label label-success"> Active </span>';
            else
                $row[2] = '<span class="label label-danger"> In Active </span>';

$e_href="";
$d_href="";
        
$profpermission=getProfpermissionbyId($_SESSION['logbyadmin']['id']);
       
if(isset($profpermission) && $profpermission->view==1 && $profpermission->edit==1){
$e_href=base_url('profession/edit').'/'.$row[0];
}
 if(isset($profpermission) &&  $profpermission->view==1 && $profpermission->delete==1){
$d_href=base_url('profession/delete').'/'.$row[0];
}


            $row[5] = '<ul class="icons-list">
                            <li class="dropdown">
                                <a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false">
                                    <i class="icon-menu9"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-right">

                                    <li><a id="edit_admin" href='.$e_href.'><i class="icon-file-excel edit_admin"></i> Edit </a></li>
                                    <li><a id="delete_admin" href='.$d_href.'><i class="icon-file-excel delete_admin"></i> Delete </a></li>
                                </ul>
                            </li>
                        </ul>';
            $output['data'][] = $row;
        }
        return $output;
    
    }



    public function getRootProfession(){
        $query = $this->db->get_where('T_PROFESSION', array('parent_id' => 0, 'status' => 1));
        if($query -> num_rows() >= 1)
            return $query->result();
        else
            return false;
    }

    public function getProfession(){
        $query = $this->db->get_where('T_PROFESSION', array('status' => 1));
        if($query -> num_rows() >= 1)
            return $query->result();
        else
            return false;
    }

    public function getProfessionInfoById($id){
        $query = $this->db->get_where('T_PROFESSION', array('status' => 1, 'id' => $id));
        if($query -> num_rows() >= 1)
            return $query->result();
        else
            return false;
    }

    public function getOtherProfessionInfoById($id){
        $query = $this->db->get_where('T_PROFESSION', array('status' => 1, 'parent_id !=' => $id));
        if($query -> num_rows() >= 1)
            return $query->result();
        else
            return false;
    }

    public function getChildProfessionInfoById($id){
        $query = $this->db->get_where('T_PROFESSION', array('status' => 1, 'parent_id' => $id));
        if($query -> num_rows() >= 1)
            return $query->result();
        else
            return false;
    }

    public function delete($id){
        $this->db->where('id',$id);
        $this->db->delete('T_PROFESSION');
        return true;
    }

    public function save($records){
        $records['created']=date('Y-m-d H:i:s');
        $query = $this->db->insert('T_PROFESSION',$records);
        $insert_id = $this->db->insert_id();
        return  $insert_id;
    }

    public function update($records,$id){
        $this->db->where('id', $id);
        $this->db->update('T_PROFESSION', $records);
    }

}