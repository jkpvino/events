<?php 
class User_model extends CI_Model {
	public function __construct()
    {
        parent::__construct();
    }
    
    public function getActiveUserList(){
      $this->db->select('*, users.id userid');
      $this->db->from('T_APP_USERS users');
      $this->db->join('T_USER_ADDRESS useraddress', 'useraddress.user_id = users.id', 'left'); 
      $this->db->where('user_status', 1);     
      $query = $this->db->get(); 
      if($query -> num_rows() >= 1)
          return $query->result();
      else
          return false;
    }

    public function getInactiveUserList(){
      $this->db->select('*, users.id userid');
      $this->db->from('T_APP_USERS users');
      $this->db->join('T_USER_ADDRESS useraddress', 'useraddress.user_id = users.id', 'left'); 
      $this->db->where('user_status', 0);     
      $query = $this->db->get(); 
      if($query -> num_rows() >= 1)
          return $query->result();
      else
          return false;
    }

    public function getAllUserList(){
      $this->db->select('*, users.id userid');
      $this->db->from('T_APP_USERS users');
      $this->db->join('T_USER_ADDRESS useraddress', 'useraddress.user_id = users.id', 'left');      
      $query = $this->db->get(); 
      if($query -> num_rows() >= 1)
          return $query->result();
      else
          return false;
    }

 public function getuserlist() {

        $aColumns = array(
            'id',
            'profile_image',
            'full_name',
            'phone_no',
            'address',
            'user_status',
            'd_created'
        );
        $sIndexColumn = "id";

        /* Total data set length */
        $sQuery = "SELECT COUNT('".$sIndexColumn."') AS row_count FROM T_APP_USERS";
        $rResultTotal = $this->db->query($sQuery);
        $aResultTotal = $rResultTotal->row();
        $iTotal = $aResultTotal->row_count;

        /*
         * Paging
         */
        $sLimit = "";
        $iDisplayStart = $this->input->get_post('start', true);
        $iDisplayLength = $this->input->get_post('length', true);
        if (isset($iDisplayStart) && $iDisplayLength != '-1') {
            $sLimit = "LIMIT " . intval($iDisplayStart) . ", " .
            intval($iDisplayLength);
        }

        $uri_string = $_SERVER['QUERY_STRING'];
        $uri_string = preg_replace("/\%5B/", '[', $uri_string);
        $uri_string = preg_replace("/\%5D/", ']', $uri_string);

        $get_param_array = explode("&", $uri_string);
        $arr = array();
        foreach ($get_param_array as $value) {
            $v = $value;
            $explode = explode("=", $v);
            $arr[$explode[0]] = $explode[1];
        }

        $index_of_columns = strpos($uri_string, "columns", 1);
        $index_of_start = strpos($uri_string, "start");
        $uri_columns = substr($uri_string, 7, ($index_of_start - $index_of_columns - 1));
        $columns_array = explode("&", $uri_columns);
        $arr_columns = array();
        foreach ($columns_array as $value) {
            $v = $value;
            $explode = explode("=", $v);
            if (count($explode) == 2) {
                $arr_columns[$explode[0]] = $explode[1];
            } else {
                $arr_columns[$explode[0]] = '';
            }
        }

        /*
         * Ordering
         */
        $sOrder = "ORDER BY ";
        $sOrderIndex = $arr['order[0][column]'];
        $sOrderDir = $arr['order[0][dir]'];
        $bSortable_ = $arr_columns['columns[' . $sOrderIndex . '][orderable]'];
        if ($bSortable_ == "true") {
            $sOrder .= $aColumns[$sOrderIndex] .
                    ($sOrderDir === 'asc' ? ' asc' : ' desc');
        }

        /*
         * Filtering
         */
        $sWhere = "";
        $sSearchVal = $arr['search[value]'];
        if (isset($sSearchVal) && $sSearchVal != '') {
            $sWhere = "WHERE (";
            for ($i = 0; $i < count($aColumns); $i++) {
                $sWhere .= $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($sSearchVal) . "%' OR ";
            }
            $sWhere = substr_replace($sWhere, "", -3);
            $sWhere .= ')';
        }

        /* Individual column filtering */
        $sSearchReg = $arr['search[regex]'];
        for ($i = 0; $i < count($aColumns); $i++) {
            $bSearchable_ = $arr['columns[' . $i . '][searchable]'];
            if (isset($bSearchable_) && $bSearchable_ == "true" && $sSearchReg != 'false') {
                $search_val = $arr['columns[' . $i . '][search][value]'];
                if ($sWhere == "") {
                    $sWhere = "WHERE ";
                } else {
                    $sWhere .= " AND ";
                }
                $sWhere .= $aColumns[$i] . " LIKE '%" . $this->db->escape_like_str($search_val) . "%' ";
            }
        }

        /*
         * SQL queries
         * Get data to display
         */
        $sQuery = "select usr.id,usr.profile_image,usr.full_name,usr.phone_no,addr.address,usr.user_status,usr.d_created FROM T_APP_USERS usr left join T_USER_ADDRESS addr on usr.id=addr.user_id";
        
        $rResult = $this->db->query($sQuery);
      
        /* Data set length after filtering */
        $sQuery = "SELECT FOUND_ROWS() AS length_count";
        $rResultFilterTotal = $this->db->query($sQuery);
        $aResultFilterTotal = $rResultFilterTotal->row();
        $iFilteredTotal = $aResultFilterTotal->length_count;

        /*
         * Output
         */
        $sEcho = $this->input->get_post('draw', true);
        $output = array(
            "draw" => intval($sEcho),
            "recordsTotal" => $iTotal,
            "recordsFiltered" => $iFilteredTotal,
            "data" => array()
        );
        foreach ($rResult->result_array() as $aRow) {
            $row = array();
            foreach ($aColumns as $col) {
                $row[] = $aRow[$col];                
            }

    
            // Profile Image
            if($row[1]){
                $row[1] = '<img class="profileimg img-circle img-sm" src="'.base_url().'assests/uploads/users/'.$row[1].'">';    
            }else{
                $row[1] = '<img class="profileimg img-circle img-sm" src="'.base_url().'assests/admin/assets/images/placeholder.jpg">';
            }


            //Online Status            
            if($row[5] == 1)
                $row[5] = '<span class="label label-success"> Online </span>';
            else
                $row[5] = '<span class="label label-danger"> Offline </span>';

            //Status

$e_href="";
$d_href="";
        
$usrpermission=getUserpermissionbyId($_SESSION['logbyadmin']['id']);
       
if(isset($usrpermission) && $usrpermission->view==1 && $usrpermission->edit==1){
$e_href=base_url('user/edituser').'/'.$row[0];
}
 if(isset($usrpermission) &&  $usrpermission->view==1 && $usrpermission->delete==1){
$d_href=base_url('user/deleteuser').'/'.$row[0];
}


 $row[7] = '<ul class="icons-list">
                            <li class="dropdown">
                                <a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false">
                                    <i class="icon-menu9"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li><a href='.$e_href.'><i class="icon-file-excel"></i> Edit </a></li>
                                    <li><a href='.$d_href.'><i class="icon-file-excel"></i> Delete </a></li>
                                </ul>
                            </li>
                        </ul>';

                    
            $output['data'][] = $row;
        }

      
        return $output;
    }

public function deleteUser($id){
        
        $limit=1;
        $query = $this->db->get_where('T_USER_ADDRESS', array('user_id' => $id), $limit);
        if($query -> num_rows() == 1){
          $this->db->where('id',$id);
        $this->db->delete('T_APP_USERS');
            
          $this->db->where('user_id',$id);
          $this->db->delete('T_USER_ADDRESS');
          return true;
          }
        else
        return false;
}









    public function isexistsemail($email){
	    $query = $this->db->get_where('bluefills_users', array('email' => $email));
	    if($query -> num_rows() >= 1)
	        return $query->result_array();
	    else
	        return false;
	}
	public function Saveuser($records){ 
	    $this->db->insert('bluefills_users', $records);     
	    $insert_id = $this->db->insert_id();
	    return  $insert_id;
	}
	public function getuserinfobyId($id){
		$query = $this->db->get_where('T_APP_USERS', array('id' => $id));
	    if($query -> num_rows() >= 1)
	        return $query->result();
	    else
	        return false;
  	}



public function getusercompleteinfobyId($id){

   $Query = "select usr.id,usr.profile_image,usr.full_name,usr.phone_no,usr.email,addr.address,addr.state,addr.nationality,usr.user_status,usr.modified_by,usr.is_blocked FROM T_APP_USERS usr join T_USER_ADDRESS addr where usr.id=".$id." and addr.user_id=".$id;
        
        $Result = $this->db->query($Query);

       //int_r($Result->result_array());
        //exit;

         if($Result -> num_rows() >= 1)
          return $Result->result();
      else
          return false;

}
  	public function getuserinfo($email, $password){
		$query = $this->db->get_where('bluefills_users', array('email' => $email, 'password' => md5($password)));		
	    if($query -> num_rows() >= 1)
	        return $query->result();
	    else
	        return false;
  	}
  	#socialMedia
  	public function getuserinfobyIdientifier($idientifier,$type){
		$query = $this->db->get_where('bluefills_users', array($type => $idientifier));
	    if($query -> num_rows() >= 1)
	        return $query->result();
	    else
	        return false;
  	}

  	public function updateSocialUserInfo($records, $idientifier,$type){
  		$this->db->where($type, $idientifier);
      	$this->db->update('bluefills_users', $records);
      	$query = $this->db->get_where('bluefills_users', array($type => $idientifier));
	    if($query -> num_rows() >= 1){
	    	$result = $query->result();
	        return $result[0]->id;
	    }
	    else
	        return false;
  	}

  	public function CreateSocialUser($records){
  		$this->db->insert('bluefills_users', $records);     
        $insert_id = $this->db->insert_id();
        if($insert_id)
        	return $insert_id;
        else
        	return false;
  	}

  	#Products
  	public function getExtensionInfoByReferenceId($referenceId){
  		$query = $this->db->get_where('bluefills_extension', array('referenceid' => $referenceId));
	    if($query -> num_rows() >= 1)
	        return $query->result();
	    else
	        return false;
  	}
  	/* Update user info */
  	public function updateUser($u_data,$log_id){
  		$this->db->where('id', $log_id);
      	$query = $this->db->update('T_APP_USERS', $u_data);
	    if($query)
	        return true;
	    else
	        return false;
  	}
  	
  	public function createOrder($records){
		$insert = $this->db->insert('bluefills_orders',$records);
		return $insert?true:false;
	}
	public function isExistsOrderByIncrementId($referenceId){
  		$query = $this->db->get_where('bluefills_orders', array('increment_id' => $referenceId));
	    if($query -> num_rows() >= 1)
	        return true;
	    else
	        return false;
  	}
  	public function completeOrderPayment($records,$referenceId){
  		$this->db->where('increment_id', $referenceId);
      	$this->db->update('bluefills_orders', $records);
      	$query = $this->db->get_where('bluefills_orders', array('increment_id' => $referenceId));

	    if($query -> num_rows() >= 1)
	        return $query->result()[0]->id;
	    else
	        return false;
  	}
        /* Get customer order list */
  	public function GetCustomerOrders($userid){
  		$query = $this->db->get_where('bluefills_orders', array('customer_id' => $userid));
	    if($query -> num_rows() >= 1){
	    	$data = $query->result();
	    	return $data;
	    }
	    else
	        return false;
  	}
  	/*Get orders by extenstion id*/
  	public function GetOrders($ext_id){
  		$query = $this->db->get_where('bluefills_extension', array('referenceid' => $ext_id));
	    if($query -> num_rows() >= 1){
	    	$data = $query->row();
	    	return $data;
	    }
	    else
	        return false;
  	}
  	/* Get file details*/
  	public function Getfiledetails($orderid,$customer_id){
  		$query = $this->db->get_where('bluefills_orders', array(
  			'customer_id' => $customer_id,
  			'order_status'=> 'completed',
  			'order_id'=>$orderid));
	    if($query -> num_rows() >= 1){
	    	$data = $query->row();
	    	return $data->extension_id;
	    }
	    else
	        return false;
  	}

  	
}