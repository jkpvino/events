<section class="section-content">
    <div class="container">
        <div class="row">
        	<div class="col-sm-1"></div>
            <div class="col-sm-10">
        		
        		<article class="page-content">
        			<p class="text-center">
        				<img src="<?= base_url('assests/frontend') ?>/images/404.png" alt="404 page">
        			</p>

        			<p>&nbsp;</p>
        			<h2 class="single-head text-center">Sorry, <strong>The Page Could not be Found</strong></h2>
        			<p class="text-center">
        				I have always wanted to have a neighbor just like you. I've always wanted to live in a neighborhood with you. No phone no lights no motor car not a single luxury. Like Robinson Crusoe it's primitive as can be. This is what we call the Muppet Show
        			</p>
        			<p>&nbsp;</p>        				
					<h4 style="text-align:center;">
						Get back to the <a href="<?= base_url() ?>">Previous page</a>
					</h4>
                    <br/>
        		</article>
            </div>
            <div class="col-sm-1"></div>
        </div>
    </div>
</section>