<!DOCTYPE html>
<html lang="en">
  <?php include('metaheader.php'); ?>
  <body>
    <!-- Header -->
    <?php include('header.php'); ?>
    <?php include('login.php'); ?>


    <!-- Banner -->
    <?php if($body_content == 'home.php'){?> 
        <div class="clearfix"> 
            <div class="clearfix container-img"> </div>
            <div class="clearfix bannercontainer container">
                <h2>We craft beautiful digital products for open source communities and consumer driven DevOps</h2>
            </div>
        </div>
        <?php #include('banner.php'); ?>
    <?php } ?>    

    <!-- Home -->
    <?php include($body_content); ?>    

    <?php include('footer.php'); ?>
    <?php include('subfooter.php'); ?> 
    <?php include('error.php'); ?>
  </body>
</html>