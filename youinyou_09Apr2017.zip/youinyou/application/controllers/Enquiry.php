<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//error_reporting(E_ALL);
class Enquiry extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->model('enquiry_model');
        
    }
    public function index(){
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );
            $data = array(
                'title' => 'Manage Enquiry',
                'subtitle' => '',
                'body_content' => 'manageenquiry/enquiry_grid.php', 
                'pagecontent' => $pagecontent,
                'method' => $_method,
            );
            $this->load->view('admin/index',$data);
        }else{
            redirect('admin', 'refresh');
        }
    }
    /* -------------Profession -------------------------*/
    public function enquirylist() {
        $results = $this->enquiry_model->getenquirylist();
        echo json_encode($results);
    }
    /*public function add(){   
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $rootProfession = $this->profession_model->getRootProfession();
            $profession = $this->profession_model->getProfession();
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );                       
            $this->form_validation->set_rules('profession_name', 'Profession Name', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim|required');            
             
            if($this->form_validation->run() == TRUE){
                $parent_id = $this->input->post('parent_id') ? $this->input->post('parent_id') : 0;
                $records = array( 
                    'profession_name' => $this->input->post('profession_name'), 
                    'parent_id' => $parent_id, 
                    'status' => $this->input->post('status'), 
                    'created_by' => $session_data['username']
                );
                $results = $this->profession_model->save($records);
                $message = 'New Profession Created Successfully';
                $this->session->set_flashdata('flash_message',$message); 
                redirect('profession', 'refresh');
            }else{
                $data = array(
                    'title' => 'Profession',
                    'subtitle' => '',
                    'body_content' => 'manageprofession/add.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                    'rootProfession' => $rootProfession,
                    'profession' => $profession
                );
                $this->load->view('admin/index',$data);
            }            
        }else{
            $message = "You Don't have rights to access this page";
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }
    public function edit($id){   
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $rootProfession = $this->profession_model->getRootProfession();
            $profession = $this->profession_model->getOtherProfessionInfoById($id);
            $professionInfo = $this->profession_model->getProfessionInfoById($id);
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );                       
            $this->form_validation->set_rules('profession_name', 'Profession Name', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim|required');            
             
            if($this->form_validation->run() == TRUE){
                $parent_id = ($this->input->post('is_root')!=0) ? $this->input->post('parent_id') : 0;
                $records = array( 
                    'profession_name' => $this->input->post('profession_name'), 
                    'parent_id' => $parent_id, 
                    'status' => $this->input->post('status'), 
                    'created_by' => $session_data['username']
                );
                $results = $this->profession_model->update($records,$id);
                $message = 'Record Updated Successfully';
                $this->session->set_flashdata('flash_message',$message); 
                redirect('profession', 'refresh');
            }else{
                $data = array(
                    'title' => 'Profession',
                    'subtitle' => '',
                    'body_content' => 'manageprofession/edit.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                    'rootProfession' => $rootProfession,
                    'profession' => $profession,
                    'professionInfo' => $professionInfo,
                    'id' => $id
                );
                $this->load->view('admin/index',$data);
            }            
        }else{
            $message = "You Don't have rights to access this page";
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }*/
    public function delete($id){
        if(isAdminLogged()){
            $results = $this->enquiry_model->delete($id);
            if($results)
                $message = 'Record is deleted Successfully';            
                $this->session->set_flashdata('flash_message',$message);
            redirect('profession', 'refresh');
        }else{
            $message = "You don't have access to Delete this Records";
            $this->session->set_flashdata('flash_message',$message);
            redirect('admin', 'refresh');
        }
    }

    /* ----------------- End Profession -------------------------*/
}
