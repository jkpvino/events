<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends CI_Controller {
    public function __construct(){

       // error_reporting(E_ALL);
        parent::__construct();
        $this->load->helper(array('form', 'url','admin_helper'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->model('user_model');
    }

    public function report($type = 0){
        header("Content-type: application/csv");
        header("Content-Disposition: attachment; filename=\"USERS_REPORT_".date('M.j.y', $from)."-".date('M.j.y', $to).".csv\"");
        header("Pragma: no-cache");
        header("Expires: 0");
        $handle = fopen('php://output', 'w');  
        fputcsv($handle, array(
            'User Id',
            'User Name',
            'Full Name',
            'Email',
            'Phone No',
            'Contact No',
            'Mobile No',
            'Location',
            'State',
            'Country',
            'Date Created',
        ));

        if($type == 1)
            $userLists = $this->user_model->getActiveUserList();
        if($type == 2)
            $userLists = $this->user_model->getInactiveUserList();
        if($type == 0 || $type == '')
            $userLists = $this->user_model->getAllUserList();

        if($userLists && count($userLists) > 0){
            foreach ($userLists as $key => $userList) {
                $userId = $userList->userid;
                fputcsv($handle, array(
                    $userId,
                    $userList->username,
                    $userList->full_name,
                    $userList->email,
                    $userList->phone_no,
                    $userList->contact_no,
                    $userList->mobile_no,                    
                    $userList->address,
                    $userList->state,
                    $userList->nationality,
                    $userList->d_created,
                ));
            }
        }
        fclose($handle);
        exit;
    }
    
    public function index(){
        //echo "kk";
        //exit;
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');
            redirect('admin/dashboard', 'refresh');
        }else{
            $data = array(
                'title' => 'Login',
                'body_content' => 'login.php', 
            );
            $this->load->view('admin/login',$data);
        }
    }
    public function loginverify(){
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|callback_check_database');
        if($this->form_validation->run() == FALSE)
        {
            $data = array(
                'title' => 'Login',
                'body_content' => 'login.php'
            );
            $this->load->view('admin/login',$data);
        }else{      
            //echo "hh";
            //eixt;
            redirect('admin/dashboard', 'refresh');
        }
    }

    public function check_database($password){
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $result = $this->admin_model->isexists($username, $password);

        if($result){
            $sess_array = array();
            foreach($result as $row){
                $sess_array = array(
                 'id' => $row->id,
                 'username' => $row->username,
                 'usertype'=> $row->usertype
                );
                $this->session->set_userdata('logbyadmin', $sess_array);
            }
            return TRUE;
        }else{
            $this->form_validation->set_message('check_database', 'Invalid username or password');
            return false;
        }
    }

    public function logout(){
        if(isAdminLogged()){
            $this->session->unset_userdata('logbyadmin');
            $this->session->sess_destroy();
            redirect('admin/index', 'refresh');
        }else{
            redirect('admin', 'refresh');
        }
    }


    public function dashboard(){
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
                'usertype' => $session_data['usertype'],
                'userscount' => getUsersCount(),
            );
            $data = array(
                'title' => 'Dashboard',
                'subtitle' => '',
                'body_content' => 'dashboard.php', 
                //'body_content' => '', 
                'pagecontent' => $pagecontent,
                'method' => $_method,
            );
            $this->load->view('admin/index',$data);
        }else{
            redirect('admin', 'refresh');
        }
    } 


    /* ----------------- User Collection ----------------- */
    public function manageuser(){
        //echo "kkk";
        //exit;
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
                'usertype' => $session_data['usertype']
            );
            $data = array(
                'title' => 'Manage Users',
                'subtitle' => '',
                'body_content' => 'manageuser/user_grid.php', 
                'pagecontent' => $pagecontent,
                'method' => $_method,
            );

         //   print_r($data);
           // exit;
            $this->load->view('admin/index',$data);
        }else{
            redirect('admin', 'refresh');
        }
    }
    public function userslist() {
        $results = $this->user_model->getuserlist();

         // echo "<pre>";
         // print_r($results);
         // exit;
        echo json_encode($results);
    }
    /* ----------------- End User Collection ----------------- */

    public function adduser(){
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
                'usertype' => $session_data['usertype']
            );                       
            $this->form_validation->set_rules('fullname', 'Name', 'trim|required');
            $this->form_validation->set_rules('avatar', 'Profile Image', '');
            $this->form_validation->set_rules('phone_no', 'Phone Number', 'trim');
            $this->form_validation->set_rules('country', 'Country', 'trim');
             $this->form_validation->set_rules('state', 'State', 'trim');
              $this->form_validation->set_rules('city', 'City', 'trim');
               $this->form_validation->set_rules('zip', 'Zip Code', 'trim');
                $this->form_validation->set_rules('address', 'Address', 'trim');
           // $this->form_validation->set_rules('usertype', 'User Group', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim|required');                
            if($this->form_validation->run() == TRUE){
                $records = array(
                            'fullname' => trim($this->input->post('fullname')), 
                            'avatar' => trim($this->input->post('avatar')), 
                            'phone_no' => trim($this->input->post('phone_no')), 
                            'country' => trim($this->input->post('country')), 
                            'state' => trim($this->input->post('state')), 
                            'city' => trim($this->input->post('city')), 
                            'zip' => trim($this->input->post('zip')), 
                            'address' => trim($this->input->post('address')), 
                            'status' => trim($this->input->post('status'))
                        );

                /*echo "<pre>";
                 print_r($records);
                exit;*/
                $results = $this->user_model->saveUser($records);
                $message = 'New User Created Successfully';
                $this->session->set_flashdata('flash_message',$message); 
                redirect('user/manageuser', 'refresh');
            }else{
                $data = array(
                    'title' => 'User',
                    'subtitle' => '',
                    'body_content' => 'manageuser/add.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                );
                // echo "<pre>";
                // print_r($data);
                // exit;
                $this->load->view('admin/index',$data);
            }
            
        }else{
            $message = "You Don't have rights to access this page";
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }
    public function isAdminExists($password){
        $username = $this->input->post('username');
        $result = $this->admin_model->isadminuserexists($username);

        if($result){
            $this->form_validation->set_message('isAdminExists', 'Admin Username Already Exists');
            return false;
        }else{
            return true;
        }
    }
    public function edituser($id){
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
                'usertype' => $session_data['usertype']
            );                       
            //$this->form_validation->set_rules('fullname', 'Name', 'trim');
            //$this->form_validation->set_rules('password', 'Password', 'trim|md5');
            //$this->form_validation->set_rules('email', 'Email', 'trim|required');
            $this->form_validation->set_rules('is_blocked', 'Block User', 'trim');
            $this->form_validation->set_rules('user_status', 'User Status', 'trim');  

            if($this->form_validation->run() == TRUE){                
                    $records = array(
                      //  'fullname' => trim($this->input->post('fullname')), 
                      //  'email' => trim($this->input->post('email')), 
                        'is_blocked' => trim($this->input->post('is_blocked')), 
                        'user_status' => trim($this->input->post('status')),
                        'd_modified' => date("Y-m-d H:i:s"),
                        'modified_by' => $session_data['username']
                    );
                       
                $message = 'Record Updated Successfully';
                $this->session->set_flashdata('flash_message',$message);        
                $results = $this->user_model->updateUser($records,$id);
                redirect('user/manageuser', 'refresh');
            }else{     
          //  echo "hi";
            //exit;            
                $data = array(
                    'title' => 'Edit User',
                    'subtitle' => '',
                    'body_content' => 'manageuser/edit.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                    'id' => $id,
                    'userinfo' => $this->user_model->getusercompleteinfobyId($id),
                    'professiontree' => $this->fetchProfessionTree(),
                );

                // echo "<pre>";
                // print_r($data);
                // exit;
                $this->load->view('admin/index',$data);
            }
            
        }else{
            $message = 'You Dont have rights to access this page';
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }    
    public function deleteuser($id){
        if(isAdminLogged()){
            $results = $this->user_model->deleteUser($id);
            $message = 'User Record deleted Successfully';
            $this->session->set_flashdata('flash_message',$message);
            redirect('user/manageuser', 'refresh');
        }else{
            $message = "You don't have access to Delete this Records";
            $this->session->set_flashdata('flash_message',$message);
            redirect('user/manageuser', 'refresh');
        }
    }

    function fetchProfessionTree($parent = 0, $spacing = '', $user_tree_array = '') { 
      if (!is_array($user_tree_array))
        $user_tree_array = array();
        $rows = $this->db
            ->select('id,parent_id,profession_name')
            ->where('parent_id', $parent)
            ->order_by('id','asc')
            ->get('T_PROFESSION')
            ->result();
        if (count($rows) > 0) {
            foreach ($rows as $row) {
              $user_tree_array[] = array("id" => $row->id, "name" => $spacing . $row->profession_name);
              $user_tree_array = $this->fetchProfessionTree($row->id, $spacing . '&nbsp;&nbsp;&nbsp;&nbsp;', $user_tree_array);
            }
        }
      return $user_tree_array;
    }



    /* ----------------- End Admin Collection -------------------------*/
}