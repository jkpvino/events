<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//error_reporting(E_ALL);
class Category extends CI_Controller {


    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->model('category_model');
    }
    public function index(){

        if(isAdminLogged()){

            $session_data = $this->session->userdata('logbyadmin');
            redirect('admin/dashboard', 'refresh');
        }else{
            $data = array(
                'title' => 'Login',
                'body_content' => 'login.php', 
            );
            $this->load->view('admin/login',$data);
        }
    }

    /* -------------Category Collection -------------------------*/
    public function managecategory(){

        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );
            $data = array(
                'title' => 'Manage Category',
                'subtitle' => '',
                'body_content' => 'managecategory/category_grid.php', 
                'pagecontent' => $pagecontent,
                'method' => $_method,
            );

         $this->load->view('admin/index',$data);
        }else{
            redirect('admin', 'refresh');
        }
    }

    public function categorylist() {
        $results = $this->category_model->getcategorylist();
        echo json_encode($results);
    }

    public function addcategory(){
       
        if(isAdminLogged()){

            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );                       
            $this->form_validation->set_rules('categoryname', 'Category Name', 'trim|required|callback_isCategoryExists');
            $this->form_validation->set_rules('url', 'Url', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim|required');
            $this->form_validation->set_rules('is_root', 'is_root', 'trim');
            $this->form_validation->set_rules('p_category', 'Parent Category', 'trim');
             
            if($this->form_validation->run() == TRUE){
                if($pagecontent['logid']==1){  $status=1; }
                else{ $status=0;}

                $is_approve=0;
                $approved_by=NULL;
               $created_by=$pagecontent['username'];
              
                $records = array(
                            'category_name' => trim($this->input->post('categoryname')), 
                            'external_url' => trim($this->input->post('url')), 
                            'status' => $status, 
                            'is_root' => trim($this->input->post('is_root')), 
                            'is_approve'=>$is_approve,
                            'created_by'=>$created_by,
                            'approved_by'=>$approved_by,                           
                        );
                $records['parent_id'] = ($this->input->post('is_root')!=0) ? $this->input->post('p_category') : 0;
                if(!empty($approved_by)){
                    $records['approved_by']= $approved_by;
                }

                $results = $this->category_model->saveCategory($records);
                if($results){
                $message = 'New Category Created Successfully';
                $this->session->set_flashdata('flash_message',$message); 
            }
            else{
                $message = 'OOPS problem in creating category';
                $this->session->set_flashdata('flash_message',$message);  
            }

                redirect('category/managecategory', 'refresh');
            }else{
              
                $pcat=$this->category_model->getParentCategory();             
                $data = array(
                    'title' => 'Category',
                    'subtitle' => '',
                    'body_content' => 'managecategory/add.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                    'parent_cat'=>$pcat
                );
             
                $this->load->view('admin/index',$data);
            }
            
        }else{
            $message = "You Don't have rights to access this page";
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }
    public function isCategoryExists($password){
        $cat_name = $this->input->post('categoryname');
        $result = $this->category_model->iscategoryexists($cat_name);

        if($result){
            $this->form_validation->set_message('isCategoryExists', 'Category name Already Exists');
            return false;
        }else{
            return true;
        }
    }
    public function editcategory($id){

        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );                       
    
            $this->form_validation->set_rules('url', 'Url', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim');
            $this->form_validation->set_rules('is_root', 'is_root', 'trim');
            $this->form_validation->set_rules('p_category', 'Parent Category', 'trim');     
            $this->form_validation->set_rules('app_status', 'Approve Status', 'trim');     

            if($this->form_validation->run() == TRUE){                
               
                    $records = array(    
                            'external_url' => trim($this->input->post('url')), 
                            'status' => trim($this->input->post('status')),  
                            'is_root' => trim($this->input->post('is_root')),
                            'modified' => date("Y-m-d H:i:s"),
                            'modified_by' => $session_data['username'],
                            'approved_by'=>$session_data['username'],
                            'is_approve'=>trim($this->input->post('app_status')),
                                    );               
                    
                $records['parent_id'] = ($this->input->post('is_root')!=0) ? $this->input->post('p_category') : 0;
                $message = 'Category Record is Updated Successfully';
                $this->session->set_flashdata('flash_message',$message);        
                $results = $this->category_model->updateCategory($records,$id);
                redirect('category/managecategory', 'refresh');
            }
            else{  
                 $pcat=$this->category_model->getParentCategory();
                 $getCategory=$this->category_model->getcategoryinfobyId($id);

                 $data = array(
                    'title' => 'Edit Category',
                    'subtitle' => '',
                    'body_content' => 'managecategory/edit.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                    'id' => $id,
                  'categoryinfo' => $getCategory,
                  'parent_cat'=>$pcat
                );
                
                $this->load->view('admin/index',$data);
            }
            
        }else{
            $message = "You Don't have rights to access this page";
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }    
    public function deletecategory($id){
        if(isAdminLogged()){
            $results = $this->category_model->deletecategory($id);
            if($results){
            $message = 'Category Record is deleted Successfully';
            }
            else{
            $message = 'Root Category Cannot be deleted';    
            }
            $this->session->set_flashdata('flash_message',$message);
            redirect('category/managecategory', 'refresh');
        }else{
            $message = "You don't have access to Delete this Records";
            $this->session->set_flashdata('flash_message',$message);
            redirect('category/managecategory', 'refresh');
        }
    }

    public function cattree(){

        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );
            $data = array(
                'title' => 'Manage Category',
                'subtitle' => '',
                'body_content' => 'managecategory/category_tree.php', 
                'pagecontent' => $pagecontent,
                'method' => $_method,
                'categories'=>$this->category_model->get_categories(),
            //    'sub_categories'=>,
            );
// //$this->load->view('view_file', $data);

           // debug($data);
            //exit;
         $this->load->view('admin/index',$data);
        }else{
            redirect('admin', 'refresh');
        }
    }









    /* ----------------- End Category Collection -------------------------*/
}
