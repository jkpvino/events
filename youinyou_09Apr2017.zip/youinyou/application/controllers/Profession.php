<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//error_reporting(E_ALL);
class Profession extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->model('profession_model');
        $this->load->model('classified_model');
        $this->load->model('category_model');
        
    }
    public function index(){
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );
            $data = array(
                'title' => 'Manage Profession',
                'subtitle' => '',
                'body_content' => 'manageprofession/profession_grid.php', 
                'pagecontent' => $pagecontent,
                'method' => $_method,
            );
            $this->load->view('admin/index',$data);
        }else{
            redirect('admin', 'refresh');
        }
    }
    /* -------------Profession -------------------------*/
    public function professionlist() {
        $results = $this->profession_model->getprofessionlist();
        echo json_encode($results);
    }
    public function add(){   
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $rootProfession = $this->profession_model->getRootProfession();
            $profession = $this->profession_model->getProfession();
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );                       
            $this->form_validation->set_rules('profession_name', 'Profession Name', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim|required');            
             
            if($this->form_validation->run() == TRUE){
                $parent_id = $this->input->post('parent_id') ? $this->input->post('parent_id') : 0;
                $records = array( 
                    'profession_name' => $this->input->post('profession_name'), 
                    'parent_id' => $parent_id, 
                    'status' => $this->input->post('status'), 
                    'created_by' => $session_data['username']
                );
                $results = $this->profession_model->save($records);
                $message = 'New Profession Created Successfully';
                $this->session->set_flashdata('flash_message',$message); 
                redirect('profession', 'refresh');
            }else{
                $data = array(
                    'title' => 'Profession',
                    'subtitle' => '',
                    'body_content' => 'manageprofession/add.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                    'rootProfession' => $rootProfession,
                    'profession' => $profession
                );
                $this->load->view('admin/index',$data);
            }            
        }else{
            $message = "You Don't have rights to access this page";
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }
    public function edit($id){   
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $rootProfession = $this->profession_model->getRootProfession();
            $profession = $this->profession_model->getOtherProfessionInfoById($id);
            $professionInfo = $this->profession_model->getProfessionInfoById($id);
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );                       
            $this->form_validation->set_rules('profession_name', 'Profession Name', 'trim|required');
            $this->form_validation->set_rules('status', 'Status', 'trim|required');            
             
            if($this->form_validation->run() == TRUE){
                $parent_id = ($this->input->post('is_root')!=0) ? $this->input->post('parent_id') : 0;
                $records = array( 
                    'profession_name' => $this->input->post('profession_name'), 
                    'parent_id' => $parent_id, 
                    'status' => $this->input->post('status'), 
                    'created_by' => $session_data['username']
                );
                $results = $this->profession_model->update($records,$id);
                $message = 'Record Updated Successfully';
                $this->session->set_flashdata('flash_message',$message); 
                redirect('profession', 'refresh');
            }else{
                $data = array(
                    'title' => 'Profession',
                    'subtitle' => '',
                    'body_content' => 'manageprofession/edit.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                    'rootProfession' => $rootProfession,
                    'profession' => $profession,
                    'professionInfo' => $professionInfo,
                    'id' => $id
                );
                $this->load->view('admin/index',$data);
            }            
        }else{
            $message = "You Don't have rights to access this page";
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }
    public function delete($id){
        if(isAdminLogged()){
            $results = $this->profession_model->delete($id);
            if($results)
                $message = 'Record is deleted Successfully';            
                $this->session->set_flashdata('flash_message',$message);
            redirect('profession', 'refresh');
        }else{
            $message = "You don't have access to Delete this Records";
            $this->session->set_flashdata('flash_message',$message);
            redirect('admin', 'refresh');
        }
    }

    public function getProfessionTreeSelect($level = 0, $prefix = '') {
        $rows = $this->db
            ->select('id,parent_id,profession_name')
            ->where('parent_id', $level)
            ->order_by('id','asc')
            ->get('T_PROFESSION')
            ->result();
        $category = '';
        $result = array();
        if (count($rows) > 0) {
            foreach ($rows as $row) {
                $category .= '<option value='.$row->id.'>'.$prefix.$row->profession_name .'</option>';
                $category .= $this->getProfessionTreeSelect($row->id, $prefix . '---');
            }
        }
        return $category;
    }
    public function printCategoryTree() {
        echo "<pre>";
        print_r($this->fetchCategoryTree());
        /*echo "<select>";
        echo $this->getProfessionTreeSelect();
        echo "</select>";*/
    }

    function fetchCategoryTree($parent = 0, $spacing = '', $user_tree_array = '') { 
      if (!is_array($user_tree_array))
        $user_tree_array = array();
        $rows = $this->db
            ->select('id,parent_id,profession_name')
            ->where('parent_id', $parent)
            ->order_by('id','asc')
            ->get('T_PROFESSION')
            ->result();
        if (count($rows) > 0) {
            foreach ($rows as $row) {
              $user_tree_array[] = array("id" => $row->id, "name" => $spacing . $row->profession_name);
              $user_tree_array = $this->fetchCategoryTree($row->id, $spacing . '&nbsp;&nbsp;', $user_tree_array);
            }
        }
      return $user_tree_array;
    }

    /* ----------------- End Profession -------------------------*/
}
