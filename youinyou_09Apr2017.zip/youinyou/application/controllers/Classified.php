<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//error_reporting(E_ALL);
class Classified extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->model('classified_model');
        $this->load->model('category_model');
        $this->load->model('enquiry_model');
        
    }
    public function index(){
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );
            $data = array(
                'title' => 'Manage Classified',
                'subtitle' => '',
                'body_content' => 'manageclassified/classified_grid.php', 
                'pagecontent' => $pagecontent,
                'method' => $_method,
            );

            $this->load->view('admin/index',$data);
        }else{
            redirect('admin', 'refresh');
        }
    }
    /* -------------Classified -------------------------*/
    public function manageclassified(){
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );
            $data = array(
                'title' => 'Manage Classified',
                'subtitle' => '',
                'body_content' => 'manageclassified/classified_grid.php', 
                'pagecontent' => $pagecontent,
                'method' => $_method,
            );

            $this->load->view('admin/index',$data);
        }else{
            redirect('admin', 'refresh');
        }
    }
    public function classifiedlist() {
        $results = $this->classified_model->getclassifiedlist();
        echo json_encode($results);
    }
    /* GET SUBCATEGORY FOR AJAX */
    public function getsubcategory(){
        $id = $_POST['id'];
        $results=$this->category_model->getsubCategorybyId($id);
        if(count($results) > 0){
            $response = '<option value=""> Select Sub Category </option>';
            foreach ($results as $key => $value) {
                $data[] = array(
                    'id' => $value['id'],
                    'name' => $value['category_name']
                );
                $response .= '<option value='.$value['id'].'> '.$value['category_name'].' </option>';
            }            
            echo $response;
            #echo json_encode($data);
        }else{
            echo '<option value=""> Select Sub Category </option>';
        }        
    }
    public function addclassified(){   
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            ); 

           // debug($_POST);
             //debug($_FILES);
            // exit;

            $this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|callback_isCategoryExists');
            $this->form_validation->set_rules('minprice', 'Minimum Price', 'trim|required');
            $this->form_validation->set_rules('maxprice', 'Minimum Price', 'trim|required');
            $this->form_validation->set_rules('title', 'Title', 'trim');
            $this->form_validation->set_rules('description', 'Description', 'trim');          

            $this->form_validation->set_rules('status', 'Status', 'trim|required'); 
            $this->form_validation->set_rules('post_status', 'Post Status', 'trim|required');      
            $this->form_validation->set_rules('is_home', 'Home Status', 'trim');      
            if (empty($_FILES['addimage']['name'][0]))
            {
    
                 $this->form_validation->set_rules('image1', 'Image 1', 'required');
            }
             
            if($this->form_validation->run() == TRUE){

                $records = array( 
                    'title' => $this->input->post('title'), 
                    'description' => $this->input->post('description'), 
                    'min_price' => $this->input->post('minprice'), 
                    'max_price' => $this->input->post('maxprice'),
                    'category_id' => $this->input->post('category_name'), 
                    'sub_cat_id' => $this->input->post('sub_category_name'), 
                    'post_status' => $this->input->post('post_status'), 
                    'status' => $this->input->post('status'), 
                    'created_by' => $session_data['username'],
                    'admin_id' => $session_data['id'],
                    'is_home'=>$this->input->post('is_home'), 
                );
               

                $imageFiles = array();
                if(!empty($_FILES['addimage']['name']) && isset($_FILES['addimage']['name'])){
                  //   echo "koo";
               // exit;

                    $results = $this->classified_model->save($records);

                    $filesCount = count($_FILES['addimage']['name']);  
                    //echo "kk".$filesCount;
                    //exit;
                    for($i = 0; $i < $filesCount; $i++){
                        $_FILES['userFile']['name'] = $_FILES['addimage']['name'][$i];
                        $_FILES['userFile']['type'] = $_FILES['addimage']['type'][$i];
                        $_FILES['userFile']['tmp_name'] = $_FILES['addimage']['tmp_name'][$i];
                        $_FILES['userFile']['error'] = $_FILES['addimage']['error'][$i];
                        $_FILES['userFile']['size'] = $_FILES['addimage']['size'][$i];
                        $uploadPath = 'assests/uploads/';
                        $config['upload_path'] = $uploadPath;
                        $config['allowed_types'] = 'gif|jpg|png|jpeg';                        
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);
                        if($this->upload->do_upload('userFile')){
                            $fileData = $this->upload->data();
                            $uploadData[$i]['file_name'] = $fileData['file_name'];
                            $uploadData[$i]['created'] = date("Y-m-d H:i:s");
                            $uploadData[$i]['modified'] = date("Y-m-d H:i:s");
                            $imageFiles = array(
                                'image' => $fileData['file_name'], 
                                'status' => 1,
                                'classified_id' => $results,
                                'sort_order' => $i
                            ); 
                            $query = $this->db->insert('T_CLASSIFIED_IMAGES',$imageFiles);
                             $message = 'New Ad Created Successfully';
                $this->session->set_flashdata('flash_message',$message); 
                redirect('classified/manageclassified', 'refresh');
                        }
                    }
                }
              
               
            }else{
                $data = array(
                    'title' => 'Classified',
                    'subtitle' => '',
                    'body_content' => 'manageclassified/add.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                   'parent_cat'=>getparentcategory(),
                   'child_cat'=>getchildcategory()
                );
                $this->load->view('admin/index',$data);
            }            
        }else{
            $message = 'You Dont have rights to access this page';
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }

    public function edit($id){   
        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );                       
            $this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|callback_isCategoryExists');
            $this->form_validation->set_rules('minprice', 'Minimum Price', 'trim|required');
            $this->form_validation->set_rules('maxprice', 'Minimum Price', 'trim|required');
            $this->form_validation->set_rules('title', 'Title', 'trim');
            $this->form_validation->set_rules('description', 'Description', 'trim');
            $this->form_validation->set_rules('status', 'Status', 'trim|required'); 
            $this->form_validation->set_rules('post_status', 'Post Status', 'trim|required');              
            $this->form_validation->set_rules('is_home', 'Home Status', 'trim');              
            //debug($_FILES);
            //exit;
             


            if($this->form_validation->run() == TRUE){


                $records = array( 
                    'title' => $this->input->post('title'), 
                    'description' => $this->input->post('description'), 
                    'min_price' => $this->input->post('minprice'), 
                    'max_price' => $this->input->post('maxprice'),
                    'category_id' => $this->input->post('category_name'), 
                    'sub_cat_id' => $this->input->post('sub_category_name'), 
                    'post_status' => $this->input->post('post_status'), 
                    'status' => $this->input->post('status'), 
                    'created_by' => $session_data['username'],
                    'admin_id' => $session_data['id'],
                    'is_home'=>$this->input->post('is_home'), 
                );
                $results = $this->classified_model->update($records,$id);

                $imageFiles = array();
                if(!empty($_FILES['addimage']['name'])){
                    $filesCount = count($_FILES['addimage']['name']);  
                    for($i = 0; $i < $filesCount; $i++){
                        $_FILES['userFile']['name'] = $_FILES['addimage']['name'][$i];
                        $_FILES['userFile']['type'] = $_FILES['addimage']['type'][$i];
                        $_FILES['userFile']['tmp_name'] = $_FILES['addimage']['tmp_name'][$i];
                        $_FILES['userFile']['error'] = $_FILES['addimage']['error'][$i];
                        $_FILES['userFile']['size'] = $_FILES['addimage']['size'][$i];
                        $uploadPath = 'assests/uploads/';
                        $config['upload_path'] = $uploadPath;
                        $config['allowed_types'] = 'gif|jpg|png|jpeg';                        
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);
                        if($this->upload->do_upload('userFile')){
                            $fileData = $this->upload->data();
                            $uploadData[$i]['file_name'] = $fileData['file_name'];
                            $uploadData[$i]['created'] = date("Y-m-d H:i:s");
                            $uploadData[$i]['modified'] = date("Y-m-d H:i:s");
                            $imageFiles = array(
                                'image' => $fileData['file_name'], 
                                'status' => 1,
                                'classified_id' => $id,
                                'sort_order' => $i
                            ); 
                            $results = $this->classified_model->updateimages($imageFiles,$id);
                            $query = $this->db->insert('T_CLASSIFIED_IMAGES',$imageFiles);
                        }
                    }
                }
                $message = 'Ad Updated Successfully';
                $this->session->set_flashdata('flash_message',$message); 
                redirect('classified/manageclassified', 'refresh');
            }else{
                $data = array(
                    'title' => 'Classified',
                    'subtitle' => '',
                    'body_content' => 'manageclassified/edit.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                   'parent_cat'=>getparentcategory(),
                   'child_cat'=>getchildcategory(),
                   'id' => $id,
                   'addinfo' => $this->classified_model->getclassifiedInfo($id),
                   'imageinfo' => $this->classified_model->getclassifiedImageInfo($id),
                   'enquiryinfo' => $this->enquiry_model->getEnquiryInfoByClassifiedId($id),
                );

                //debug($data);
                //exit;
                $this->load->view('admin/index',$data);
            }            
        }else{
            $message = "You Don't have rights to access this page";
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }

    public function delete($id){
        if(isAdminLogged()){
            $results = $this->classified_model->delete($id);
            if($results)
                $message = 'Record is deleted Successfully';            
                $this->session->set_flashdata('flash_message',$message);
            redirect('classified/manageclassified', 'refresh');
        }else{
            $message = "You don't have access to Delete this Records";
            $this->session->set_flashdata('flash_message',$message);
            redirect('classified/manageclassified', 'refresh');
        }
    }

    public function isCategoryExists($password){
        $cat_name = $this->input->post('categoryname');
        $result = $this->category_model->iscategoryexists($cat_name);
        if($result){
            $this->form_validation->set_message('isCategoryExists', 'Category Name Already Exists');
            return false;
        }else{
            return true;
        }
    }
    /* ----------------- End Classified -------------------------*/
}
