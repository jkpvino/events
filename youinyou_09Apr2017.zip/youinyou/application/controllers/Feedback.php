<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//error_reporting(E_ALL);
class Feedback extends CI_Controller {


    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->model('feedback_model');
    }
    public function index(){

        if(isAdminLogged()){

            $session_data = $this->session->userdata('logbyadmin');
            redirect('admin/dashboard', 'refresh');
        }else{
            $data = array(
                'title' => 'Login',
                'body_content' => 'login.php', 
            );
            $this->load->view('admin/login',$data);
        }
    }

    /* -------------Feedback Collection -------------------------*/
    public function managefeedback(){

        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );
            $data = array(
                'title' => 'Manage Feedback',
                'subtitle' => '',
                'body_content' => 'managefeedback/feedback_grid.php', 
                'pagecontent' => $pagecontent,
                'method' => $_method,
            );

         $this->load->view('admin/index',$data);
        }else{
            redirect('admin', 'refresh');
        }
    }

    public function feedbacklist() {
        $results = $this->feedback_model->getfeedbacklist();
        //debug($results);
        //exit;
        echo json_encode($results);
    }

   
    public function isCategoryExists($password){
        $cat_name = $this->input->post('categoryname');
        $result = $this->category_model->iscategoryexists($cat_name);

        if($result){
            $this->form_validation->set_message('isCategoryExists', 'Category name Already Exists');
            return false;
        }else{
            return true;
        }
    }
    public function editfeedback($id){

        if(isAdminLogged()){
            $session_data = $this->session->userdata('logbyadmin');        
            $_method = $this->router->fetch_method();   
            $pagecontent = array(
                'username' => $session_data['username'], 
                'logid' => $session_data['id'],
            );                       
    
         //   $this->form_validation->set_rules('customername', 'customer name', 'trim');
           // $this->form_validation->set_rules('status', 'Status', 'trim');
            $this->form_validation->set_rules('is_app', 'is_app', 'trim');
          //  $this->form_validation->set_rules('p_category', 'Parent Category', 'trim');     
 

            if($this->form_validation->run() == TRUE){                
               
                    $records = array(    
                           
                            //'is_approve' => trim($this->input->post('is_app')),
                           // 'modified' => date("Y-m-d H:i:s"),
                            //'modified_by' => $session_data['username'],
                            'approved_by'=>$session_data['username']
                                    );               
                    
                $records['is_approve'] = ($this->input->post('is_app')!=0) ? 1 : 0;
                $message = 'Updated Successfully';
                $this->session->set_flashdata('flash_message',$message);        
                $results = $this->feedback_model->updateFeedback($records,$id);
                redirect('feedback/managefeedback', 'refresh');
            }
            else{  
               // echo "hi";
               // exit;
               
                 $data = array(
                    'title' => 'Edit Feedback',
                    'subtitle' => '',
                    'body_content' => 'managefeedback/edit.php', 
                    'pagecontent' => $pagecontent,
                    'method' => $_method,
                    'id' => $id,
                  'feedinfo' => $this->feedback_model->getfeedbackinfobyID($id),
                 
                );
                
                // debug($data);
                // exit;
                $this->load->view('admin/index',$data);
            }
            
        }else{
            $message = "You Don't have rights to access this page";
            $this->session->set_flashdata('flash_message',$message);  
            redirect('admin', 'refresh');
        }
    }    
    public function deletefeedback($id){
              if(isAdminLogged()){
            $results = $this->feedback_model->deleteFeedback($id);
            $results = $this->feedback_model->deleteFeedback($id);
            // debug($results);
            // exit;
            $message = 'Record deleted Successfully';
            $this->session->set_flashdata('flash_message',$message);
            redirect('feedback/managefeedback', 'refresh');
        }else{
            $message = "You don't have access to Delete this Records";
            $this->session->set_flashdata('flash_message',$message);
            redirect('feedback/managefeedback', 'refresh');
        }
    }
    /* ----------------- End Feedback Collection -------------------------*/
}
